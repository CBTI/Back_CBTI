""" 
import pymysql.cursors

def create_table():
    conn = pymysql.connect(
        host = HOST, 
        user = USER,
        password = PW,
        db = DB,
        charset = 'utf-8',
    )

    # sql = "CREATE TABLE USERS (
    #         USER ID VARCHAR(20) NOT NULL PRIMARY KEY,
    #         USER_NM VARCHAR(20) NOT NULL COMMENT '사용자명',
    #         TEL_NO  VARCHAR(20) COMMENT '전화번호',
    #         EMAIL   VARCHAR(30) COMMENT '이메일',)"
    
    try:
        with conn.cursor() as cursor:
            cursor.execute(sql)
        conn.commit()
    finally:
        conn.close()
    
 """