# app의 urls.py
from django.contrib import admin
from django.urls import path, include
from . import views# cbtiapp 의 views

urlpatterns = [
    path('', views.index, name = 'index')
]