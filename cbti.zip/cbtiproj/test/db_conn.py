import ibm_db# pip install ibm_db
""" 
#conn to local or cataloged DB
# 1. non persistent connection 비지속연경 자원요청할떄마다 TCP Conn 생성
conn = ibm_db.connect('database', 'username', 'password')

# 2. persistent connection 지속연결 하나의 TCP Conn 생성 후 그 연결을 통해 모든 요청 처리
pconn = ibm_db.pconnect('database', 'username', 'password')

# 3. connect to an uncataloged DB
conn = ibm_db.connect('DATABASE=name; HOSTNAME=host; PORT=60000; PROTOCOL=TCPIP; UID=username; PWD=password;', "", "")

# SQL execute
# Insert
conn = ibm_db.connect(f"DATABASE={DATABASE}; HOSTNAME={HOSTNAME};PORT={PORT};PROTOCOL=TCPIP;UID={USER_NAME};PWD={PASSWORD};", "", "")

try : 
	#SQL 문 작성
	sql = "INSERT INTO survey_resp_cantrl (survey_no,email ,value_type, value) VALUES(?,?,?,?);"
	stmt = ibm_db.prepare(conn, sql)
	param = {VALUE1}, {VALUE2}, {VALUE3}, {VALUE4}
	ibm_db.execute(stmt, param)
except: 
    print(f'error occured. {ibm_db.stmt_errormsg()}')
finally: 
    conn.close()


# SELECT문
conn = ibm_db.connect(f"DATABASE={DATABASE}; HOSTNAME={HOSTNAME};PORT={PORT};PROTOCOL=TCPIP; UID={USER_NAME};PWD={PASSWORD};", "", "")

def select_all():
    sql = 'SELECT * FROM table' 
    try: 
    	stmt = ibm_db.exec_immediate(conn, sql) 
        row = ibm_db.fet_assoc(stmt) 
        while row: 
        	print(row) 
            row = ibm_db.fetch_assoc(stmt) 
    except:
        print(f'error occured. {ibm_db.stmt_errormsg()}') 
    finally: 
    	conn.close() 
        
def select_specific(condition): 
#using prepared-statement! 
	sql = 'SELECT * FROM table WHERE condition = ? ' 
    try: 
    	stmt = ibm_db.prepare(conn, sql) 
        # option 1 : Explicitly bind parameters 
        ibm_db.bind_param(stmt, 1, condition) 
        ibm_db.execute(stmt) 
        
        # option 2 : Invoke Prepared Statement again using dynamically bound parameters. 
        param = condition 
        ibm_db.execute(stmt, param) 
    except:
        print(f'error occured. {ibm_db.stmt_errormsg()}') 
    finally: 
    	conn.close()
"""